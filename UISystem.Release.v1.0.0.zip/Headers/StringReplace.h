#pragma once
#include <string>

namespace StrReplace
{
	void ReplaceChar(std::string& Target, char A, std::string b);
}